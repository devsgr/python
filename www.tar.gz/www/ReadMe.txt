1.	Install R-pi with desktop (www.raspberrypi.org/software/), then run on a R-pi. I use Raspberry Pi OS Imager 
2.	When burning, I used username kira. The default is pi Change kira to pi in subsequent instructions if keeping pi
3.	Using Imager choose Pi OS (32 bit). Lite is headless and difficult to work with.
4.	Insert pi in R-pi 4 and run it.
5.	Optional: Turn on VNC viewer (for local or web)
6.	Update R-Pi
	a.	Sudo apt-get update &
	b.	Sudo apt-get upgrade
7.	If connecting to AirVandal Guest (or home wifi) set up the network (with user name and password) skip this and the next step. If using air-vandal Gold, follow this step. Install network-manager for air vandal gold. Warning:  after disabling dhcpcd, the remote connection would not work . Must be connected locally to reenable network-manager below.
	sudo apt-get install network-manager network-manager-gnome
	sudo systemctl disable --now dhcpcd
	sudo systemctl enable --now network-manager
	nm-applet

8.	Connect to Air-Vandal Gold with following setting
	Security: “WPA & WPA2 Enterprise”
	Authentication: “Protected EAP (PEAP)”
	Anonymous identity: [leave blank]
	CA Certificate: check “No CA certificate is required”
	PEAP version: “Automatic”
	Inner authentication: “MSCHAPv2”
	Username: [your vandal web id] 
	Password: [your vandal web password]

9.	Disable screen blanking from Pi-configuration >> Display.
10.	From terminal copy python code that will run to display webpage and turn screen on or off at set times. Unclutter to remove the cursor from screen and file that will run 	automatically at startup after connecting to wifi.
sudo apt-get install unclutter
mkdir ~/.config/autostart
wget https://raw.githubusercontent.com/devsgr/python/main/www.tar.gz 
tar -xzf www.tar.gz
rm www.tar.gz
mv ~/www/run.desktop ~/.config/autostart
11.	Set up for the kiosk
	a.	Open slidesv2.py  under www folder and modify the BaseURL
	b.	Channel = "12342567" #Thigspeak Channel
	c.	ReadAPI = "READAPI123456789" # API Key to read
	d.	WriteAPI = "WRITEAPI12345678" # API Key to write
	e.	Replace kira to with user name
	b.	Open ~/.config/autostart/run.desktop
	a.	Replace kira to with user name
12.	Reboot Pi. The website should load in full screen. If you need to close Kiosk for any reason press ALT+F4